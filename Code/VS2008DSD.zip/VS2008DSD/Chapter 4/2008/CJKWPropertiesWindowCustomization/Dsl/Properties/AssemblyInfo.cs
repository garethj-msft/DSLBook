#region Using directives

using System;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.ConstrainedExecution;

#endregion

//
// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
//
[assembly: AssemblyTitle(@"")]
[assembly: AssemblyDescription(@"")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany(@"CJKW")]
[assembly: AssemblyProduct(@"CJKWPropertiesWindowCustomization")]
[assembly: AssemblyCopyright("")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: System.Resources.NeutralResourcesLanguage("en")]

//
// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version 
//      Build Number
//      Revision
//
// You can specify all the values or you can default the Revision and Build Numbers 
// by using the '*' as shown below:

[assembly: AssemblyVersion(@"1.0.0.0")]
[assembly: ComVisible(false)]
[assembly: CLSCompliant(true)]
[assembly: ReliabilityContract(Consistency.MayCorruptProcess, Cer.None)]

//
// Make the Dsl project internally visible to the DslPackage assembly
//
[assembly: InternalsVisibleTo(@"CJKW.CJKWPropertiesWindowCustomization.DslPackage, PublicKey=00240000048000009400000006020000002400005253413100040000010001007163EC9675B460892296592EEF7DDB4F5FF024E9A2623BFC66E28C23B1A73A1F4612DCAB6DB391CD55F027BB5CDF1E6973D477A2E8AD67DF36CC71D8F4F1A8FB8DC2BA13F2DB8C8C4E62EADC00859B07DD9330841718D073969F15FC81767BB2C8EAE4D64DE71829CE67771172F77FE79F8AE14FC27134450164E61EC726B3A8")]