#region Using directives

using System;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.ConstrainedExecution;

#endregion

//
// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
//
[assembly: AssemblyTitle(@"")]
[assembly: AssemblyDescription(@"")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany(@"CJKW")]
[assembly: AssemblyProduct(@"ClassDiagram")]
[assembly: AssemblyCopyright("")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: System.Resources.NeutralResourcesLanguage("en")]

//
// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version 
//      Build Number
//      Revision
//
// You can specify all the values or you can default the Revision and Build Numbers 
// by using the '*' as shown below:

[assembly: AssemblyVersion(@"1.0.0.0")]
[assembly: ComVisible(false)]
[assembly: CLSCompliant(true)]
[assembly: ReliabilityContract(Consistency.MayCorruptProcess, Cer.None)]

//
// Make the Dsl project internally visible to the DslPackage assembly
//
[assembly: InternalsVisibleTo(@"CJKW.ClassDiagram.DslPackage, PublicKey=002400000480000094000000060200000024000052534131000400000100010015348ECEDF1C83068C890C375E0A4D37E7A0E9220F413AFC83052B0039CA1E96F9FB7870FCD942EB530D60E5491683EE32937D1E007FB832EF29C7E05A246604B6262EAA54B28997240AEBD39AA062E0833A156E2CA1EA6DDB9EB03AFABE10717D8EB79CBDF9A7BEC00B6083F9EB0ECC821C6D95F82BF8B7455A43CA24B55FD3")]