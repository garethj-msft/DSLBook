#region Using directives

using System;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.ConstrainedExecution;

#endregion

//
// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
//
[assembly: AssemblyTitle(@"")]
[assembly: AssemblyDescription(@"")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany(@"CJKW")]
[assembly: AssemblyProduct(@"CJKWTaskFlow")]
[assembly: AssemblyCopyright("")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: System.Resources.NeutralResourcesLanguage("en")]

//
// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version 
//      Build Number
//      Revision
//
// You can specify all the values or you can default the Revision and Build Numbers 
// by using the '*' as shown below:

[assembly: AssemblyVersion(@"1.0.0.0")]
[assembly: ComVisible(false)]
[assembly: CLSCompliant(true)]
[assembly: ReliabilityContract(Consistency.MayCorruptProcess, Cer.None)]

//
// Make the Dsl project internally visible to the DslPackage assembly
//
[assembly: InternalsVisibleTo(@"CJKW.CJKWTaskFlow.DslPackage, PublicKey=0024000004800000940000000602000000240000525341310004000001000100B7B61A3DEEF235F754C88848B2BC8BABCB63C890CC235331BD63501B148857FFCABAF1C5E91A10A9C0B658742317B993D6E682E28E646567BA8F58542640BBDCC47B8FC9B822A95B44333AC1FE22F52E8CF65482C03B884F66A43E75EEF450356D0EBE5536A7E531CA4FB301F249FA7F7B36D6F54C0C76834BCCAE8FE8F6A5C5")]