using System;
using System.Windows.Forms;
using Microsoft.VisualStudio.Modeling;

namespace CJKW.CJKWCustomEditor
{
	public partial class ViewForm : UserControl
	{
        private CJKWCustomEditorDocView docView;

        internal ViewForm(CJKWCustomEditorDocView docView)
        {
            this.docView = docView;
            InitializeComponent();
        }

		private void addButton_Click(object sender, EventArgs e)
		{
			if (!string.IsNullOrEmpty(this.nameTextBox.Text))
			{
				this.addElement(this.nameTextBox.Text);
			}
		}

        private void addElement(string name)
        {
            using (Transaction t = this.docView.DocData.Store.TransactionManager.BeginTransaction(Properties.Resources.Undo_AddElement))
            {
                ExampleElement newElement = new ExampleElement(this.docView.DocData.Store);
                newElement.Name = name;
                (this.docView.DocData.RootElement as ExampleModel).Elements.Add(newElement);
                t.Commit();
            }
        }

        private void updateButton_Click(object sender, EventArgs e)
        {
            this.SuspendLayout();
            this.elementList.Items.Clear();
            foreach (ExampleElement exampleElement in this.docView.DocData.Store.ElementDirectory.FindElements<ExampleElement>())
            {
                this.elementList.Items.Add(exampleElement.Name);
            }
            this.ResumeLayout();
        }
	}
}
