#region Using directives

using System;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.ConstrainedExecution;

#endregion

//
// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
//
[assembly: AssemblyTitle(@"")]
[assembly: AssemblyDescription(@"")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany(@"CJKW")]
[assembly: AssemblyProduct(@"CJKWTaskFlow")]
[assembly: AssemblyCopyright("")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: System.Resources.NeutralResourcesLanguage("en")]

//
// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version 
//      Build Number
//      Revision
//
// You can specify all the values or you can default the Revision and Build Numbers 
// by using the '*' as shown below:

[assembly: AssemblyVersion(@"1.0.0.0")]
[assembly: ComVisible(false)]
[assembly: CLSCompliant(true)]
[assembly: ReliabilityContract(Consistency.MayCorruptProcess, Cer.None)]

//
// Make the Dsl project internally visible to the DslPackage assembly
//
[assembly: InternalsVisibleTo(@"CJKW.CJKWTaskFlow.DslPackage, PublicKey=00240000048000009400000006020000002400005253413100040000010001006B0E21232753C5398F7CF89D30F271E9791362DC869FB8F0296ED2A8F1583825B9DDBF3FF65C21AF3C3323D844321669B549FFF69CF8DB10BC71EAC0C7BC48136402DFE884085E8E72EC26864E41B734438EA0B1CB0085F36FABD37B08DB1F7AD55F26CE6E9EB6E704AF8BE2F2321C7885F0983F2201A1EF2E625BF4AF16B2AE")]