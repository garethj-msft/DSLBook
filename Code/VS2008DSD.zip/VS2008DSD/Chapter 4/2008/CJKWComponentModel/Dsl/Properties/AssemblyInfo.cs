#region Using directives

using System;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.ConstrainedExecution;

#endregion

//
// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
//
[assembly: AssemblyTitle(@"")]
[assembly: AssemblyDescription(@"")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany(@"CJKW")]
[assembly: AssemblyProduct(@"CJKWComponentModels")]
[assembly: AssemblyCopyright("")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: System.Resources.NeutralResourcesLanguage("en")]

//
// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version 
//      Build Number
//      Revision
//
// You can specify all the values or you can default the Revision and Build Numbers 
// by using the '*' as shown below:

[assembly: AssemblyVersion(@"1.0.0.0")]
[assembly: ComVisible(false)]
[assembly: CLSCompliant(true)]
[assembly: ReliabilityContract(Consistency.MayCorruptProcess, Cer.None)]

//
// Make the Dsl project internally visible to the DslPackage assembly
//
[assembly: InternalsVisibleTo(@"CJKW.CJKWComponentModels.DslPackage, PublicKey=0024000004800000940000000602000000240000525341310004000001000100796C0CD9B177D33EBF8058E20D8A0CBCB001ECEBAB505544A9267A50756E34F630CE164C0FDA198CE3B7E58878C0D0C485E74FFABC00B67FF8E959E943C870E10CFB82074D4F16A5C19A2226FA47A142D670C2EE8EC046215B0746ED9F1F4556B6D80B241F71AAE12AB88CCC5664D3B80A966868A6C02A953544E74DAFC07DCB")]