using System;
using System.Collections.Generic;
using System.Text;

namespace CJKW.IssueProject
{
    public partial class ProjectCategoryConnector
    {
        [CLSCompliant(false)]
        protected override Microsoft.VisualStudio.Modeling.Diagrams.GraphObject.VGRoutingStyle DefaultRoutingStyle
        {
            get
            {
                return Microsoft.VisualStudio.Modeling.Diagrams.GraphObject.VGRoutingStyle.VGRouteTreeNS;
            }
        }
    }

    public partial class CategoryTreeConnector
    {
        [CLSCompliant(false)]
        protected override Microsoft.VisualStudio.Modeling.Diagrams.GraphObject.VGRoutingStyle DefaultRoutingStyle
        {
            get
            {
                return Microsoft.VisualStudio.Modeling.Diagrams.GraphObject.VGRoutingStyle.VGRouteTreeNS;
            }
        }
    }
}
