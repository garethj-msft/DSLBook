using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.VisualStudio.Modeling;
using System.Diagnostics;

namespace CJKW.IssueProject
{
    public partial class IssueCategory
    {
        /// <summary>
        /// The project that a category is ultimately parented by.
        /// </summary>
        public Project Project
        {
            get
            {
                Project proj = ProjectHasCategories.GetProject(this);
                if (proj == null)
                {
                    Debug.Assert(this.ParentCategory != null, "Category shoudl be nested if it is not project-parented.");
                    return this.ParentCategory.Project;
                }
                return proj;
            }
        }

        /// <summary>
        /// Connect a comment in to the model.
        /// </summary>
        /// <param name="sourceElement"></param>
        /// <param name="elementGroup"></param>
        protected override void MergeRelateComment(Microsoft.VisualStudio.Modeling.ModelElement sourceElement, Microsoft.VisualStudio.Modeling.ElementGroup elementGroup)
        {
            base.MergeRelateComment(sourceElement, elementGroup);

            // For non-top-level comments we'll need to add this in.
            if (this.ParentCategory != null)
            {
                Comment comment = sourceElement as Comment;
                this.Project.Model.Comments.Add(comment);
            }
        }

        /// <summary>
        /// Disconnect a comment from the model
        /// </summary>
        /// <remarks>
        /// Base provides the reference.
        /// Override to provide the embedding.
        /// </remarks>
        /// <param name="sourceElement"></param>
        protected override void MergeDisconnectComment(ModelElement sourceElement)
        {
            base.MergeDisconnectComment(sourceElement);

            // For non-top-level comments we'll need to remove this.
            if (this.ParentCategory != null)
            {
                Comment comment = sourceElement as Comment;
                this.Project.Model.Comments.Remove(comment);
            }
        }
    }
}
