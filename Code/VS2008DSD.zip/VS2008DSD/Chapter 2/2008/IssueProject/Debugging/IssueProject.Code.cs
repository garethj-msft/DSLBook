﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Healthcare.IssueTracker.BusinessLogicLayer
{
    public class HealthcareProjectIssue : ASPNET.StarterKit.IssueTracker.BusinessLogicLayer.Issue
    {
        private bool _clinicalsignoffrequired;
        private bool? _clinicalsignoffreceived;

        public bool ClinicalSignoffRequired
        {
            get { return _clinicalsignoffrequired; }
            set { _clinicalsignoffrequired = value; }
        }
        public bool? ClinicalSignoffReceived
        {
            get { return _clinicalsignoffreceived; }
            set { _clinicalsignoffreceived = value; }
        }

		public new bool Save()
		{
			// Save the standard Issue part
			base.Save();
            
			// Save the custom fields for the issue.
			CustomFieldCollection fields =
				CustomField.GetCustomFieldsByProjectId(ProjectId);

			foreach (CustomField field in fields)
			{
                if (StringComparer.Ordinal.Compare(field.Name, "ClinicalSignoffRequired") == 0)
                {
					field.Value = this.ClinicalSignoffRequired;
					continue;
				}
                if (StringComparer.Ordinal.Compare(field.Name, "ClinicalSignoffReceived") == 0)
                {
	                if (this.ClinicalSignoffReceived != null)
					{
						field.Value = this.ClinicalSignoffReceived;
						continue;
					}
				}
            }
			CustomField.SaveCustomFieldValues(this.Id, fields);

        }

        public HealthcareProjectIssue
						  (	int id,
							int projectId,
							string title,
							int categoryId,
							int milestoneId,
							int priorityId,
							int statusId,
							int assignedId,
							int ownerId,
							string creatorUsername,
							bool clinicalsignoffrequired
						  )
			: base(id, projectId, title, categoryId, milestoneId, priorityId, statusId, assignedId, ownerId, creatorUsername)
        {
			_clinicalsignoffrequired = clinicalsignoffrequired;
			_clinicalsignoffreceived = false;
        }


	}
}

