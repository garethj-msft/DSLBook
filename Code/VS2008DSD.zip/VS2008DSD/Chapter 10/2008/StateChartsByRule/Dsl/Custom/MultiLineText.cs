/***************************************************************************
Copyright (C) 2007 Steve Cook, Gareth Jones, Stuart Kent, Alan Cameron Wills.
Portions Copyright (C) 2007 Pearson Education, Inc.
All rights reserved.
This code is provided as-is without warranty of 
any kind, either express or implied, including any
implied warranties of fitness for a particular
purpose, merchantability, or non-infringement.
***************************************************************************/


/*
 * Multi line comments.
 * 
 * This customization demonstrates how to make a text decorator in a shape
 * have multiple lines.
 * 
 * In DSL Definition, set the GeneratesDoubleDerived property of CommentBoxShape.
 * 
 */

using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.VisualStudio.Modeling.Diagrams;

namespace CJKW.StateCharts
{

    partial class CommentBoxShape
    {
        /// <summary>
        /// GeneratesDoubleDerived must be set, to be able to override this.
        /// </summary>
        /// <param name="shapeFields"></param>
        /// <param name="decorators"></param>
        protected override void InitializeDecorators(IList<ShapeField> shapeFields, System.Collections.Generic.IList<Decorator> decorators)
        {
            base.InitializeDecorators(shapeFields, decorators);

            TextField commentField = (TextField)ShapeElement.FindShapeField(shapeFields, "Comment");
            commentField.DefaultAutoSize = false; // auto-size not supported on multi-line text fields.
            commentField.DefaultMultipleLine = true;
            commentField.AnchoringBehavior.Clear(); // clear existing anchors, set up custom anchoring below.
            commentField.AnchoringBehavior.SetLeftAnchor(AnchoringBehavior.Edge.Left, 0.01);
            commentField.AnchoringBehavior.SetRightAnchor(AnchoringBehavior.Edge.Right, 0.01);
            commentField.AnchoringBehavior.SetTopAnchor(AnchoringBehavior.Edge.Top, 0.01);
            commentField.AnchoringBehavior.SetBottomAnchor(AnchoringBehavior.Edge.Bottom, 0.01);
        }
    }
}
