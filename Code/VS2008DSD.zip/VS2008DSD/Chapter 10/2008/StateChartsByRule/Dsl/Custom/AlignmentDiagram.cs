/***************************************************************************
Copyright (C) 2007 Steve Cook, Gareth Jones, Stuart Kent, Alan Cameron Wills.
Portions Copyright (C) 2007 Pearson Education, Inc.
All rights reserved.
This code is provided as-is without warranty of 
any kind, either express or implied, including any
implied warranties of fitness for a particular
purpose, merchantability, or non-infringement.
***************************************************************************/

using System;
using System.Collections.Generic;
using System.Text;

namespace CJKW.StateCharts
{
    public partial class StateDiagram
    {

        public override double DefaultGridSize
        {
            get
            {
                return 0.01;
            }
        }
    }
}
