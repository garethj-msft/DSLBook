/***************************************************************************
Copyright (C) 2007 Steve Cook, Gareth Jones, Stuart Kent, Alan Cameron Wills.
Portions Copyright (C) 2007 Pearson Education, Inc.
All rights reserved.
This code is provided as-is without warranty of 
any kind, either express or implied, including any
implied warranties of fitness for a particular
purpose, merchantability, or non-infringement.
***************************************************************************/

using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.VisualStudio.Modeling;
using Microsoft.VisualStudio.Modeling.Diagrams;


/* First method of nesting shapes.
 * 
 * Uses the built-in nesting feature of the graphical engine. 
 * The amount of custom code is small, but (in the current version of DSL Tools) the facilities are limited.
 * See "A DSL Using Nested Child Shapes" near figure 10-8.
 * 
 * An alternative approach using rules is demonstrated in the StateChartsByRule example.
 */

namespace CJKW.NestingDemo
{
	internal sealed partial class FixUpDiagram
	{

		/// <summary>
		/// Return the logical parent MEL for a given ExampleChild
		/// </summary>
		/// <remarks>
		/// The shape mapped to this MEL will be used as the visual parent for the shape mapped to the ExampleChild
		/// </remarks>
		/// <param name="childElement"></param>
		/// <returns></returns>
		private ModelElement GetParentForExampleChild(ExampleChild childElement)
		{
			// This code defeats the "no-shape nesting" constraint built in to DSL Tools V1.
			return childElement.ExampleElement;
		}
	}

	public partial class ExampleShape
	{
		/// <summary>
		/// Ensure that nested child shapes don't go outside the bounds of parent by resizing parent.
		/// </summary>
		public override bool AllowsChildrenToResizeParent { get { return false; } }

	/*	/// <summary>
		/// Ensure that parent shape is never resized too small to cause children to be outside of it.
		/// </summary>
		public override Microsoft.VisualStudio.Modeling.Diagrams.SizeD MinimumResizableSize
		{
			get
			{
				return this.CalculateMinimumSizeBasedOnChildren();
			}
		}
        */
		#region Expand/Collapse support
		/// <summary>
		/// Decide what collapsing means for the bounds of this shape.
		/// </summary>
		protected override void Collapse()
		{
			base.Collapse(); // Remove child shapes
			this.ExpandedBounds = this.AbsoluteBounds;
			this.AbsoluteBounds = new RectangleD(this.Location, new SizeD(0.5, 0.5));
		}

		/// <summary>
		/// Decide what expanding means for the boudns of this shape.
		/// </summary>
		protected override void Expand()
		{
			base.Expand();
			this.AbsoluteBounds = this.ExpandedBounds;
		}
		#endregion
	}
}
