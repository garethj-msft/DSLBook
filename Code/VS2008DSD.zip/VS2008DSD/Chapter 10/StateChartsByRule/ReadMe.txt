Contained shapes - method 2.

This is more complex than using the current built-in nested shapes, but is more flexible.

See Chapter 10, section "Shape containment using rules", near Figure 10-11.