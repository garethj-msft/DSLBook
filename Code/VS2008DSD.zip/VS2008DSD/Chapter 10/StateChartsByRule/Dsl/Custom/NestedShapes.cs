
/*
 * Nested Shapes.
 * 
 * There is limited support for nested shapes in DSL Tools Version 1.
 * However, it is possible to achieve a similar effect with custom code.
 * 
 * In this sample, states can be nested inside each other.
 *    - Nesting on the diagram is reflected in a reference relationship in the model.
 *    - State shapes nested in another move as a group with their parent.
 *    - Shapes re-order themselves so that parents are always behind children.
 * 
 * There are three principal parts:
 *    - Restrict the user's ability to resize and move States
 *        - Parent states can't be reduced in size so as to exclude their children 
 *                - user must explicitly move a child outside
 *        - Child states can't be increased in size beyond the bounds of their parent
 *        - NestedStates can't be dropped on the boundary of a parent shape - must be either in or out
 * 
 *    - Move children with parent and adjust their Z-Order (who's in front of who) so children are in front
 *        - Resizing parent doesn't move children, but can change Z-Order
 *
 *    - Update the StateNestsFlowElements relationship to reflect nesting on the diagram
 *        - The effect can be seen in the Parent property in the properties window
 * 
 * Restricting resize and move: a BoundsRule.
 *    BoundsRules are designed for the purpose of restricting resizing and moving 
 *    gestures. During resizing, they operate while the user is moving the mouse,
 *    and reflect the restrictions in the rubber band.
 * 
 *    To write a BoundsRule, create a subclass of BoundsRules, and override 
 *    the BoundsRules property in the shape you want it to apply to.
 * 
 * Moving and updating: a Rule.
 *    Rules are designed to propagate changes, without needing to reprogram the locus of the change. 
 *    In this example, a rule is set to fire on changes to the ContainerShape. 
 *    It will run near the end of the transaction in which the changes are applied.
 *    If it causes further changes - for example in the bounds of nested shapes -
 *    then further invocations of the rule will be scheduled for them.
 * 
 * 
 * 
 * DSL Definition
 * 
 * The model in this example includes a reference relationship "StateNestsFlowElements".
 * This is not mapped to a connector, but instead is updated with changes in the nesting on the diagram.
 * When a new flow element is dropped from the toolbox onto a state, an Element Merge Directive
 * (defined on State and accepting FlowElements) both creates a link of StateNestsFlowElements,
 * as well as embedding the new FlowElement in the model root.
 * 
 * All the states are embedded directly in the model root via StateGraphHasFlowElements.
 * An alternative would be to allow flow elements to be embedded either in StateGraph or in another state,
 * and dispense with StateNestsFlowElements. This turns out slightly more complex in regard
 * to ShapeMaps, and has the effect of making new Flow Elements' names local to their initial parents.
 * 
 * All the shapes and connectors are parented on the main Diagram. An alternative would be to
 * add each shape to NestedChildShapes of its parent shape. This is somewhat more complicated
 * in terms of allowing the user to stretch and move shapes freely, and also restricts 
 * connections. In this design, connectors can cross shape boundaries without difficulty.
 *    
 * 
 * Known Issues:
 *    - User can stretch a shape underneath another, making it look as though they are
 *      nested, but this is not reflected in the model.
 *    - Some ambiguity is removed by preventing a state from being moved to straddle
 *      the boundary of its current parent; but it can end up straddling the boundary
 *      of some other shape.
 * 
 */

using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.VisualStudio.Modeling;
using Microsoft.VisualStudio.Modeling.Diagrams;

namespace CJKW.StateCharts
{

    #region Restrict resizing and movement: a BoundsRule.


    public partial class StateShape
    {
        public override BoundsRules BoundsRules
        { get { return new StateShapeBoundsRule(); } }
    }


    /// <summary>
    /// Restrict user's ability to resize, reshape or move a shape.
    /// Must be instantiated in BoundsRules property of applicable Shape.
    /// </summary>
    public class StateShapeBoundsRule : BoundsRules
    {
        /// <summary>
        /// Called to validate the new shape or position of a shape.
        /// 
        /// During resizing/reshaping, called repeatedly as the user moves the mouse. 
        /// Provides feedback to the user in the rubber band.
        /// 
        /// On the user moving a shape, this is called once to validate the new position.
        /// 
        /// </summary>
        /// <param name="shape">Shape the user is moving or reshaping/resizing</param>
        /// <param name="proposedBounds">Bounds the user is asking for</param>
        /// <returns>Acceptable bounds</returns>
        public override RectangleD GetCompliantBounds(ShapeElement shape, RectangleD proposedBounds)
        {
			try
			{
				if (IsDeserializing(shape))
					return proposedBounds;

				NodeShape stateShape = shape as StateShape;
				if (stateShape == null) return proposedBounds;

                FlowElement state = stateShape.ModelElement as FlowElement;
				if (state == null) return proposedBounds;

				// Are we moving or resizing?
				if (!ApproxEqual(proposedBounds.Height, shape.AbsoluteBoundingBox.Height)
					|| !ApproxEqual(proposedBounds.Width, shape.AbsoluteBoundingBox.Width))
				{
					// resizing
					return RestrictResize(state, stateShape, proposedBounds);
				}
				else
				{
					return RestrictMovement(state, stateShape, proposedBounds);
				}
			}
			catch (NullReferenceException e)
			{
				System.Windows.Forms.MessageBox.Show(e.StackTrace);
				return proposedBounds;
			}
        }


        /// <summary>
        /// Get the shape that presents a state in a diagram.
        /// </summary>
        /// <param name="state"></param>
        /// <param name="diagram">Diagram we're expecting the shape to be in.</param>
        /// <returns></returns>
        internal static NodeShape ShapeOf(FlowElement state, Diagram diagram)
        {
            foreach (PresentationElement pel in PresentationViewsSubject.GetPresentation(state))
            {
                NodeShape stateShape = pel as NodeShape;
                if (stateShape != null && stateShape.Diagram == diagram) return stateShape;
            }
            return null;
        }

		/// <summary>
		/// Are we currently deserializing?
		/// </summary>
		/// <param name="element">Any item in the store</param>
		/// <returns>True iff currently deserializing.</returns>
		internal static bool IsDeserializing (ModelElement element)
		{
			Transaction transaction = element.Store.TransactionManager.CurrentTransaction;
			return transaction != null && transaction.IsSerializing;
		}

		/// <summary>
		/// Compare values ignoring rounding errors to 1 part in a million.
		/// </summary>
		/// <param name="a"></param>
		/// <param name="b"></param>
		/// <returns></returns>
		internal static bool ApproxEqual(double a, double b)
		{
			return Math.Round(a, 6) == (Math.Round(b, 6));
		}
    
        /// <summary>
        /// Restrict a shape to being either inside or outside its current parent - not straddling the boundary.
        /// </summary>
        /// <param name="state"></param>
        /// <param name="stateShape"></param>
        /// <param name="proposedBounds"></param>
        /// <returns></returns>
        private static RectangleD RestrictMovement(FlowElement state, NodeShape stateShape, RectangleD proposedBounds)
        {
            RectangleD acceptableBounds = proposedBounds;
            if (state.Parent != null)
            {
                NodeShape parentShape = ShapeOf(state.Parent, stateShape.Diagram);
                if (parentShape != null)
                {
                    if (ContainerShapeChangesRule.MovingShapes(stateShape.Store).Contains(parentShape)) return acceptableBounds;

                    if (!parentShape.AbsoluteBoundingBox.Contains(proposedBounds))
                    {
                        // The proposedBounds are either outside the parent shape, or cross its border.

                        RectangleD intersection = RectangleD.Intersect(proposedBounds, parentShape.AbsoluteBoundingBox);
                        if (intersection.Height > 0.0)
                        {
                            // The proposed bounds cross the parent's boundary. Is it more in or more out? Compare areas.
                            if (intersection.Height * intersection.Width * 2 > proposedBounds.Width * proposedBounds.Height)
                            {
                                // More in than out: move back in, with a margin.
                                if (proposedBounds.X < parentShape.AbsoluteBoundingBox.X) acceptableBounds.X = parentShape.AbsoluteBoundingBox.X + 0.1;
                                if (proposedBounds.Right > parentShape.AbsoluteBoundingBox.Right) acceptableBounds.X = parentShape.AbsoluteBoundingBox.Right - proposedBounds.Width - 0.1;
                                if (proposedBounds.Y < parentShape.AbsoluteBoundingBox.Y) acceptableBounds.Y = parentShape.AbsoluteBoundingBox.Y + 0.1;
                                if (proposedBounds.Bottom > parentShape.AbsoluteBoundingBox.Bottom) acceptableBounds.Y = parentShape.AbsoluteBoundingBox.Bottom - proposedBounds.Height - 0.1;
                            }
                            else
                            {
                                // More out than in : move out
                                if (proposedBounds.Right > parentShape.AbsoluteBoundingBox.Right) acceptableBounds.X = parentShape.AbsoluteBoundingBox.Right;
                                else if (proposedBounds.Left < parentShape.AbsoluteBoundingBox.Left) acceptableBounds.X = parentShape.AbsoluteBoundingBox.X - proposedBounds.Width;
                                else if (proposedBounds.Bottom > parentShape.AbsoluteBoundingBox.Bottom) acceptableBounds.Y = parentShape.AbsoluteBoundingBox.Bottom;
                                else if (proposedBounds.Top < parentShape.AbsoluteBoundingBox.Top) acceptableBounds.Y = parentShape.AbsoluteBoundingBox.Y - proposedBounds.Height;
                            }
                        }
                    }
                }
            }
            return acceptableBounds;
        }

        /// <summary>
        /// As the user moves a side or corner, restrict movement so that child shapes are enclosed and the parent shape encloses.
        /// </summary>
        /// <param name="state"></param>
        /// <param name="stateShape"></param>
        /// <param name="proposedBounds"></param>
        /// <returns></returns>
        private static RectangleD RestrictResize(FlowElement state, NodeShape stateShape, RectangleD proposedBounds)
        {
            RectangleD acceptableBounds = new RectangleD(proposedBounds.X, proposedBounds.Y, 
                Math.Max(proposedBounds.Width, stateShape.MinimumSize.Width), Math.Max(proposedBounds.Height, stateShape.MinimumSize.Height));
            // Ensure we don't reduce so much as to exclude children's shapes. Consider only if we're reducing size.
            if (proposedBounds.Height < stateShape.AbsoluteBoundingBox.Height || proposedBounds.Width < stateShape.AbsoluteBoundingBox.Width)
            {
                RectangleD minimumBounds = ChildBounds(state, stateShape);
                if (minimumBounds.Height > 0.0)
                {
                    // must enclose existing children
                    acceptableBounds = RectangleD.Union(acceptableBounds, minimumBounds);
                }
            }

            // Ensure we don't increase size beyond parent's boundary; consider only if we're increasing size.
            if (proposedBounds.Height > stateShape.AbsoluteBoundingBox.Height || proposedBounds.Width > stateShape.AbsoluteBoundingBox.Width)
            {
                if (state.Parent != null)
                {
                    NodeShape parentShape = ShapeOf(state.Parent, stateShape.Diagram);
                    if (parentShape != null)
                    {
                        acceptableBounds = RectangleD.Intersect(acceptableBounds, parentShape.AbsoluteBoundingBox);
                    }
                }
            }
            return acceptableBounds;
        }


        /// <summary>
        /// Find minimal rectangle that encloses shapes of children
        /// </summary>
        /// <param name="stateShape"></param>
        /// <returns>Empty rectangle if no children</returns>
        private static RectangleD ChildBounds(FlowElement flowElement, NodeShape stateShape)
        {
            
            RectangleD minimal = RectangleD.Empty;

            State state = flowElement as State;
            if (state == null) return minimal;

            bool doneFirstChild = false;
            foreach (FlowElement child in state.Children)
            {
                NodeShape childShape = ShapeOf(child, stateShape.Diagram);
                if (childShape != null)
                {
                    if (!doneFirstChild)
                    {
                        minimal = childShape.AbsoluteBoundingBox;
                        doneFirstChild = true;
                    }
                    else
                    {
                        minimal = RectangleD.Union(minimal, childShape.AbsoluteBoundingBox);
                    }
                }
            }

            return minimal;
        }
    }
    #endregion

    public partial class State
    {
        internal sealed partial class SortPropertyHandler
        {
            protected override void OnValueChanged(State element, TaskSort oldValue, TaskSort newValue)
            {
                base.OnValueChanged(element, oldValue, newValue);
            }
        }
        
    }
    #region Moving and updating: a Rule.

    /// <summary>
    /// The domain model class.
    /// </summary>
    public partial class StateChartsDomainModel
    {
        /// <summary>
        /// Register rules.
        /// </summary>
        /// <returns></returns>
        protected override Type[] GetCustomDomainModelTypes()
        {
            return new System.Type[] { typeof(ContainerShapeChangesRule), typeof(ContainerShapeInlineChangesRule) };
        }
    }

    [RuleOn(typeof(NodeShape), FireTime = TimeToFire.Inline)]
    public sealed class ContainerShapeInlineChangesRule : Microsoft.VisualStudio.Modeling.ChangeRule
    {
        public override void ElementPropertyChanged(ElementPropertyChangedEventArgs e)
        {
                NodeShape stateShape = e.ModelElement as NodeShape;
                if (stateShape == null) return;
                if (StateShapeBoundsRule.IsDeserializing(stateShape)) return;
                if (e.DomainProperty.Id == NodeShape.AbsoluteBoundsDomainPropertyId)
                {
                    ContainerShapeChangesRule.MovingShapes(stateShape.Store).Add(stateShape);
                }
        }
        
    }
 
    /// <summary>
    /// Rule will fire at the end of a transaction in which a change has been made
    /// to any stored property of StateShape.
    /// Must be registered in the domain model class, StatesDomainModel.
    /// </summary>
    [RuleOn(typeof(NodeShape), FireTime = TimeToFire.TopLevelCommit)]
    public sealed class ContainerShapeChangesRule : Microsoft.VisualStudio.Modeling.ChangeRule
    {
        public static List<NodeShape> MovingShapes(Store store)
        {
            if (!store.TransactionManager.InTransaction) return new List<NodeShape>();
            Dictionary<object, object> context = store.TransactionManager.CurrentTransaction.Context.ContextInfo;
            if (!context.ContainsKey("ContainerShapeChangesRule"))
            {
                context.Add("ContainerShapeChangesRule", new List<NodeShape>());
            }
            return context["ContainerShapeChangesRule"] as List<NodeShape>;
        }

        public override void ElementPropertyChanged(ElementPropertyChangedEventArgs e)
        {
			try
            { 
                
                NodeShape stateShape = e.ModelElement as NodeShape;
                if (stateShape == null) return;
                if (StateShapeBoundsRule.IsDeserializing(stateShape)) return;
				if (e.DomainProperty.Id == NodeShape.AbsoluteBoundsDomainPropertyId)
				{
					RectangleD oldBounds = (RectangleD)e.OldValue;

					// Use current shape here, as newValue has not been adjusted by the BoundsRule
					RectangleD newBounds = stateShape.AbsoluteBoundingBox;

					double dw = newBounds.Width - oldBounds.Width;
					double dh = newBounds.Height - oldBounds.Height;
					double dx = newBounds.X - oldBounds.X;
					double dy = newBounds.Y - oldBounds.Y;

					// Moved or resized? If we're moving, the height and width don't change.
					if (dw == 0.0 && dh == 0.0)
					{
                        CheckNoObscure(stateShape);
						// moving
						MoveNestedStates(stateShape, dx, dy, dw, dh);
					}

                    Reparent(stateShape, newBounds);
                    FixZOrder(stateShape); 

				}
			}
			catch (NullReferenceException exception)
			{
				System.Windows.Forms.MessageBox.Show(exception.StackTrace);
			}
        }

        /// <summary>
        /// You aren't allowed to move a shape so that it contains another unrelated shape.
        /// This is because, if you were to move a family on top of another family,
        /// there would be interleavings of generations that the user would find difficult to predict.
        /// </summary>
        /// <param name="movedShape"></param>
        private void CheckNoObscure(NodeShape movedShape)
        {
            bool seenMe = false;
            foreach (ShapeElement shapeElement in movedShape.Diagram.NestedChildShapes)
            {
                NodeShape nodeShape = shapeElement as NodeShape;
                if (nodeShape == movedShape) seenMe = true;
                else
                {
                    if (nodeShape != null && movedShape.AbsoluteBoundingBox.Contains(nodeShape.AbsoluteBoundingBox))
                    {
                        if (!seenMe || !IsShapeOfChild(movedShape, nodeShape))
                        {
                            throw new InvalidOperationException("Cannot move a shape so as to capture another. Move the other onto this first.");
                        }
                    }
                }
            }
        }
        private static bool IsShapeOfChild(NodeShape parentShape, NodeShape childShape)
        {
            FlowElement parent = parentShape.ModelElement as FlowElement;
            if (parent == null) return true;
            FlowElement child = childShape.ModelElement as FlowElement;
            if (child == null) return false;
            for (FlowElement element = child.Parent; element != null && element != child; element = element.Parent)
            {
                if (element == parent) return true;
            }
            return false;
        }

        #region Propagate movements to children


        /// <summary>
        /// This version should run after Reparenting
        /// Recently-moved items are in front of their siblings and all their children.
        /// NestedStates are in front of their parents.
        /// Connectors are in front of shapes.
        /// </summary>
        /// <param name="movedShape"></param>
        private void FixZOrder(NodeShape movedShape)
        {
            FlowElement state = movedShape.ModelElement as FlowElement;
            if (state == null) return;

            // If this shape is obscured by another, 
            // move it and children to front.

            // Count children and count items after me in zorder.
            List<FlowElement> movedGroup = new List<FlowElement>();
            movedGroup.Add(state);
            ListNestedStates(state, movedGroup);

            LinkedElementCollection<ShapeElement> allShapes = movedShape.ParentShape.NestedChildShapes;

            int allShapesTop = allShapes.Count - 1;
            while (allShapesTop > 0 && allShapes[allShapesTop] is BinaryLinkShape) allShapesTop--;

            double topZOrder = allShapes[allShapes.Count - 1].ZOrder;

            // Move all connectors to end of list
            for (int i = 0; i < allShapesTop; )
            {
                if (allShapes[i] is BinaryLinkShape)
                {
                    allShapes.Move(i, allShapes.Count - 1);
                    topZOrder += 1.0;
                    allShapes[allShapes.Count - 1].ZOrder = topZOrder;
                    allShapesTop--;
                }
                else
                {
                    i++;
                }
            }

            // Move shape group
            if (allShapesTop + 1 - allShapes.IndexOf(movedShape) != movedGroup.Count)
            {
                foreach (FlowElement groupMember in movedGroup)
                {
                    NodeShape groupMemberShape = StateShapeBoundsRule.ShapeOf(groupMember, movedShape.Diagram);
                    allShapes.Move(groupMemberShape, allShapesTop);
                    topZOrder += 1.0;
                    groupMemberShape.ZOrder = topZOrder;
                }
            }

        }

        private void ListNestedStates(FlowElement parent, List<FlowElement> breadthFirst)
        {
            State parentState = parent as State;
            if (parentState == null) return;

            foreach (FlowElement child in parentState.Children)
            {
                breadthFirst.Add(child);
                ListNestedStates(child, breadthFirst);
            }
        }


        /// <summary>
        /// Move Shapes that belong to the children of the element owning this shape.
        /// </summary>
        /// <param name="shape">shape of parent element</param>
        /// <param name="dx"></param>
        /// <param name="dy"></param>
        /// <param name="dw"></param>
        /// <param name="dh"></param>
        private void MoveNestedStates(NodeShape shape, double dx, double dy, double dw, double dh)
        {
            State state = shape.ModelElement as State;
            if (state == null) return;
            SizeD offset = new SizeD(dx, dy);

            List<NodeShape> moving = MovingShapes(shape.Store);

            foreach (FlowElement child in state.Children)
            {
                foreach (PresentationElement pel in PresentationViewsSubject.GetPresentation(child))
                {
                    NodeShape childShape = pel as NodeShape;
                    if (childShape == null || childShape.Diagram != shape.Diagram) continue;
                    if (!moving.Contains(childShape))
                        childShape.Location = PointD.Add(childShape.Location, offset);
                }
            }
        }
        #endregion

        #region Reflect diagram changes in the model
        private void Reparent(NodeShape shape, RectangleD newBounds)
        {
            if (shape == null || shape.Diagram == null) return;
            FlowElement state = shape.ModelElement as FlowElement;
            if (state == null) return;

            StateShape closestFit = null;
            // find the shape that most closely encloses this, if any
            foreach (ShapeElement shapeElement in shape.Diagram.NestedChildShapes)
            {
                StateShape stateShape = shapeElement as StateShape;
                if (stateShape != null && stateShape != shape)
                {
                    if (stateShape.AbsoluteBoundingBox.Contains(newBounds))
                    {
                        closestFit = stateShape;
                    }
                }
            }
            if (closestFit == null)
            {
                state.Parent = null;
            }
            else
            {
                // Parent should be the closestFit's state
                State newParent = closestFit.ModelElement as State;
                if (newParent != null)
                {
                    state.Parent = newParent;
                }
            }
        }
        #endregion
    }


    #endregion


}
