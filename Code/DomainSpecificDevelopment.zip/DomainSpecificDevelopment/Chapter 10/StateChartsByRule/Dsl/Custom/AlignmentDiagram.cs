using System;
using System.Collections.Generic;
using System.Text;

namespace CJKW.StateCharts
{
    public partial class StateDiagram
    {

        public override double DefaultGridSize
        {
            get
            {
                return 0.01;
            }
        }
    }
}
