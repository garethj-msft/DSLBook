using System;
using System.Collections.Generic;
using System.Text;

using Microsoft.VisualStudio.Modeling;
using Microsoft.VisualStudio.Modeling.Diagrams;

namespace CJKW.StateCharts
{

    public partial class StateDiagram
    {

        protected override void InitializeResources(StyleSet classStyleSet)
        {
            base.InitializeResources(classStyleSet);

            this.Store.EventManagerDirectory.ElementPropertyChanged.Add(
                this.Store.DomainDataDirectory.FindDomainClass(typeof(State)),
                new EventHandler<ElementPropertyChangedEventArgs> (StateChangeHandler)); 
        }

        private void StateChangeHandler(object sender, ElementPropertyChangedEventArgs e)
        {
            State changedElement = e.ModelElement as State;
            if (e.DomainProperty.Id == State.NameDomainPropertyId)
            {
                // respond to name change...
            }
        }
    }



    public partial class AbstractGeometryShape
    {
        public override void OnDragLeave(DiagramPointEventArgs e)
        {
            if (System.Windows.Forms.Control.ModifierKeys == System.Windows.Forms.Keys.Control)
            {
                e.DiagramClientView.ActiveMouseAction = new CtrlDragMouseAction(this.ModelElement as FlowElement);
            }
            else
                base.OnDragLeave(e);
        }
        public override System.Windows.Forms.Cursor GetCursor(System.Windows.Forms.Cursor currentCursor, DiagramClientView diagramClientView, PointD mousePosition)
        {
            return System.Windows.Forms.Cursors.NoMove2D;
        }
        public override void OnDragDrop(DiagramDragEventArgs e)
        {
            base.OnDragDrop(e);
        }
    }

    public class CtrlDragMouseAction : MouseAction
    {
        private FlowElement original;
        
        public CtrlDragMouseAction(FlowElement element) { original = element; }

        protected override void OnDragCompleted(MouseActionEventArgs e)
        {
            base.OnDragCompleted(e);
            
        }
        protected override void Dispose(bool disposing)
        {
            base.Dispose(disposing);
        }
    }

    public partial class StateShape
    {
        protected override void InitializeInstanceResources()
        {
            base.InitializeInstanceResources();
            this.DoubleClick += new DiagramPointEventHandler(StateShape_DoubleClick);
        }

        void StateShape_DoubleClick(object sender, DiagramPointEventArgs e)
        {
            StateShape shape = sender as StateShape;
            // respond to DoubleClick ...
        }
    }

}
