
/* Nesting shapes, method 1.
 * 
 * Uses the built-in nesting feature of the graphical engine. 
 * The amount of custom code is small, but (in the current version of DSL Tools) the facilities are limited.
 * See "A DSL Using Nested Child Shapes" near figure 10-8.
 * 
 * An alternative approach using rules is demonstrated in the StateChartsByRule example.
 */