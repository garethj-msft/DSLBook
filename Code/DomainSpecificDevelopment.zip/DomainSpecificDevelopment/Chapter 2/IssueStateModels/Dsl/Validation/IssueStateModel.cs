using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.VisualStudio.Modeling.Validation;
using Microsoft.VisualStudio.Modeling;

namespace CJKW.IssueStateModels
{
    [ValidationState(ValidationState.Enabled)]
    public partial class IssueState
    {
        [ValidationMethod(ValidationCategories.Menu | ValidationCategories.Save | ValidationCategories.Open)]
        private void ValidateStatesReachable(ValidationContext context)
        {
            if (this.Successors.Count == 0 & this.Predecessors.Count == 0 & this.StartElement == null)
            {
                context.LogError("State "+this.Name+" is unreachable",
                                 "Err 01",
                                 this);
            }
        }

    }
}
