using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.VisualStudio.Modeling.Diagrams;

namespace CJKW.IssueProject
{
   
    public partial class CommentBoxShape
    {
        //InitializeDecorators is called once for each shape instance. Be sure to call its base:
        protected override void InitializeDecorators(IList<ShapeField> shapeFields, System.Collections.Generic.IList<Decorator> decorators)
        {
            base.InitializeDecorators(shapeFields, decorators);
         
            //You need to find the appropriate shape field. Referring to the definition of CommentBoxShape in DslDefinition.dsl, you can see that its text decorator is called "Text".
            TextField commentField =
                (TextField)ShapeElement.FindShapeField(shapeFields, "Text");

           commentField.DefaultAutoSize = false;
            
           // auto-size not supported on multi-line text fields.
           commentField.DefaultMultipleLine = true;

           //Now we need to have the text field border track the dimensions of its parent shape. This is done by setting anchors. The small numbers are inset margins, so that the corner of the field is slightly inside the corner of the shape:
           commentField.AnchoringBehavior.Clear(); // clear existing anchors
           commentField.AnchoringBehavior.SetLeftAnchor
                                          (AnchoringBehavior.Edge.Left, 0.01);
           commentField.AnchoringBehavior.SetRightAnchor
                                          (AnchoringBehavior.Edge.Right, 0.01);
           commentField.AnchoringBehavior.SetTopAnchor
                                          (AnchoringBehavior.Edge.Top, 0.01);
           commentField.AnchoringBehavior.SetBottomAnchor
                                          (AnchoringBehavior.Edge.Bottom, 0.01);
           
        }
    }
     
}
