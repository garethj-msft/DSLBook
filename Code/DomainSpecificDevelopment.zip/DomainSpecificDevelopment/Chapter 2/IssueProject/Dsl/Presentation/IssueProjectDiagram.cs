using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.VisualStudio.Modeling;
using Microsoft.VisualStudio.Modeling.Diagrams;

namespace CJKW.IssueProject
{
    public partial class IssueProjectDiagram
    {
        private NodeShape GetTargetShapeForCommentConnector(CommentConnector connector)
        {
            ModelElement element = null;
            if (connector.Subject != null)
            {
                CommentReferencesSubjects link = connector.Subject as CommentReferencesSubjects;
                CommentableItem item = link.CommentableItem;
                if (item is Project || item is IssueCategory)
                {
                    element = item;
                }
                else // Any other kind that is in a compartment on the Project
                {
                    element = ProjectHasCommentableItems.GetProject(item);
                }
            }
            return (NodeShape)GetRepresentation(element);
        }

        /// <summary>
        /// Given a connector connected to end nodes, get the target MEL for the underlying REL
        /// </summary>
        /// <param name="connector"></param>
        /// <returns></returns>
        private ModelElement GetTargetRolePlayerForLinkMappedByCommentConnector(CommentConnector connector)
        {
            ShapeElement shape = connector.ToShape;
            if (shape is CategoryShape)
            {
                return shape.Subject;
            }
            else
            {
                throw new OperationCanceledException("Ambiguous endpoint for this connector");
            }
        }

        /// <summary>
        /// Get the representation of the given element on this diagram
        /// </summary>
        /// <param name="element"></param>
        private ShapeElement GetRepresentation(ModelElement element)
        {
            foreach (PresentationElement pres in PresentationViewsSubject.GetPresentation(element))
            {
                ShapeElement shape = pres as ShapeElement;
                if (shape != null && object.Equals(this, shape.Diagram))
                {
                    return shape;
                }
            }
            return null;
        }
    }
}
