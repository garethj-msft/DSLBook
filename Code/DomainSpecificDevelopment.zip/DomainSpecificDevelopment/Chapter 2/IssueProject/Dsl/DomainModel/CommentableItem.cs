using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.VisualStudio.Modeling;

namespace CJKW.IssueProject
{
    public partial class CommentableItem
    {
        /// <summary>
        /// Connect a comment in to the model
        /// </summary>
        /// <remarks>
        /// Base provides the reference.
        /// Override to provide the embedding.
        /// </remarks>
        /// <param name="sourceElement"></param>
        /// <param name="elementGroup"></param>
        protected virtual void MergeRelateComment(ModelElement sourceElement, ElementGroup elementGroup)
        {
            Comment comment = sourceElement as Comment;
            this.Comments.Add(comment);

            Project project = ProjectHasCommentableItems.GetProject(this);
            if (project != null)
            {
                project.Model.Comments.Add(comment);
            }
        }

        /// <summary>
        /// Disconnect a comment from the model
        /// </summary>
        /// <remarks>
        /// Base provides the reference.
        /// Override to provide the embedding.
        /// </remarks>
        /// <param name="sourceElement"></param>
        protected virtual void MergeDisconnectComment(ModelElement sourceElement)
        {
            Comment comment = sourceElement as Comment;
            this.Comments.Remove(comment);

            Project project = ProjectHasCommentableItems.GetProject(this);
            if (project != null)
            {
                project.Model.Comments.Remove(comment);
            }
        }
        
    }
}
