using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.VisualStudio.Modeling;

namespace CJKW.IssueProject
{
    public partial class Project
    {
        /// <summary>
        /// Connect a comment in to the model.
        /// </summary>
        /// <param name="sourceElement"></param>
        /// <param name="elementGroup"></param>
        protected override void MergeRelateComment(Microsoft.VisualStudio.Modeling.ModelElement sourceElement, Microsoft.VisualStudio.Modeling.ElementGroup elementGroup)
        {
            base.MergeRelateComment(sourceElement, elementGroup);

            Comment comment = sourceElement as Comment;
            this.Model.Comments.Add(comment);
        }

        /// <summary>
        /// Disconnect a comment from the model
        /// </summary>
        /// <remarks>
        /// Base provides the reference.
        /// Override to provide the embedding.
        /// </remarks>
        /// <param name="sourceElement"></param>
        protected override void MergeDisconnectComment(ModelElement sourceElement)
        {
            base.MergeDisconnectComment(sourceElement);

            Comment comment = sourceElement as Comment;
            this.Model.Comments.Remove(comment);
        }
    }
}
