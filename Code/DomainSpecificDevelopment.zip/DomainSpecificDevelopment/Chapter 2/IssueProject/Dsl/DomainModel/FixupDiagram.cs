using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.VisualStudio.Modeling;

namespace CJKW.IssueProject
{
    /// <summary>
    /// Rule that initiates view fixup when an element that has an associated shape is added to the model. 
    /// </summary>
    internal sealed partial class FixUpDiagram : AddRule
    {
        // Method:
        // must be implemented in a partial class of CJKW.IssueProject.FixUpDiagram.  Given a child element,
        // this method should return the parent model element that is associated with the shape or diagram that will be the parent 
        // of the shape created for this child.  If no shape should be created, the method should return null.
        // parentElement = GetParentForIssueCategory((global::CJKW.IssueProject.IssueCategory)childElement);
        private ModelElement GetParentForIssueCategory(IssueCategory childElement)
        {
            return childElement.Project.Model;
        }

		 private ModelElement GetParentForCommentReferencesSubjects(CommentReferencesSubjects childLink)
		 {
             return childLink.Comment.Model;
		 }
    }
}
