using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel.Design;
using Microsoft.VisualStudio.Modeling.Shell;
using Microsoft.VisualStudio.Modeling;
using System.Diagnostics;
using Microsoft.VisualStudio.Modeling.Diagrams;

namespace CJKW.IssueProject
{

    internal static partial class Constants
    {
        // Command definitions
        public static readonly global::System.ComponentModel.Design.CommandID AddCommentCommand = new global::System.ComponentModel.Design.CommandID(new global::System.Guid(IssueProjectCommandSetId), 0x0002);
    }

    /// <summary>
    /// Double-derived class to allow easier code customization.
    /// </summary>
    internal partial class IssueProjectCommandSet : IssueProjectCommandSetBase
    {
        protected override IList<System.ComponentModel.Design.MenuCommand> GetMenuCommands()
        {
            List<MenuCommand> commands = new List<MenuCommand>(base.GetMenuCommands());
            MenuCommand menuCommand = new DynamicStatusMenuCommand(new EventHandler(OnStatusAddComment),
                new EventHandler(OnMenuAddComment),
                Constants.AddCommentCommand);
            commands.Add(menuCommand);
            return commands;
        }

        /// <summary>
        /// Status event handler for adding a comment.
        /// </summary>
        internal virtual void OnStatusAddComment(object sender, global::System.EventArgs e)
        {
            System.ComponentModel.Design.MenuCommand cmd = sender as System.ComponentModel.Design.MenuCommand;
            ShapeElement shape = this.SingleDocumentSelection as ShapeElement;
            cmd.Enabled = cmd.Visible = (this.SingleDocumentSelection != null && ( this.SingleDocumentSelection is CommentableItem||
                                                                                    shape.Subject is CommentableItem));
        }

        /// <summary>
        /// Handler for adding a comment.
        /// </summary>
        internal virtual void OnMenuAddComment(object sender, System.EventArgs e)
        {
            using (Transaction t = this.CurrentDocData.Store.TransactionManager.BeginTransaction("Add Comment"))
            {
                Comment newComment = new Comment(this.CurrentDocData.Store);
                ShapeElement shape = this.SingleDocumentSelection as ShapeElement;
                CommentableItem item = this.SingleDocumentSelection as CommentableItem;
                if (item == null && shape != null)
                {
                    // Maybe it's a shape
                    item = shape.Subject as CommentableItem;
                }
                Debug.Assert(item != null, "Selection not commentable.");
                item.Comments.Add(newComment);
                Project project = item as Project;
                if (item == null)
                {
                    project = ProjectHasCommentableItems.GetProject(item);
                }
                Debug.Assert(project != null, " Project not reached.");
                if (project != null && project.Model != null)
                {
                    project.Model.Comments.Add(newComment);
                }
                t.Commit();
            }
        }
    }
}
