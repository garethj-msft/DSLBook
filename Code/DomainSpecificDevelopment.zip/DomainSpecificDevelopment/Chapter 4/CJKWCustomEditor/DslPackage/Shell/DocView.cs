namespace CJKW.CJKWCustomEditor
{
    // Double-derived class to allow easier code customization.
    internal partial class CJKWCustomEditorDocView : CJKWCustomEditorDocViewBase
    {
        // The WinForms form that implements this view
        private ViewForm viewForm;

        public override System.Windows.Forms.IWin32Window Window
        {
            get
            {
                if (this.viewForm == null)
                {
                    this.viewForm = new ViewForm(this);
                }
                return this.viewForm;
            }
        }
    }
}
